﻿namespace OnlineShoppingApp.Repositories;

public class Class1
{

}
