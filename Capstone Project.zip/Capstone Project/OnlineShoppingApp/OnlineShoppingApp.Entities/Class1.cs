﻿namespace OnlineShoppingApp.Entities;

public class Class1
{

}
