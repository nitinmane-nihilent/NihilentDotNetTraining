﻿namespace OnlineShoppingApp.Services;

public class Class1
{

}
